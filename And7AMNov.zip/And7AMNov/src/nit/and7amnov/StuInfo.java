package nit.and7amnov;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/sinfo")
public class StuInfo {
	
	static ArrayList<String> list = new ArrayList<String>( );
	
	@Path("/insert/{name}/{gender}/{qual}/{yop}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public String insertStuInfo(
			@PathParam("name") String name,
			@PathParam("gender") String gender,
			@PathParam("qual") String qual,
			@PathParam("yop") String yop) {
		
String msg = "{\"name\":\""+name+"\",\"gender\":\""+gender+"\",\"qual\":\""+qual+"\",\"yop\":"+yop+"}";		 

list.add(msg);

System.out.println(msg); 

	return "{\"status\":\"success\"}"; 	
	}
	
	@Path("/read")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public String readStuInfo( )
	{ 
		
		String result = "{\"results\":[";
		for(int i=0;i<list.size();i++)
		{
			if(i!=list.size()-1) {
			result = result + list.get(i) +","; 
			}else {
				result = result + list.get(i) ;
			}
		}
		 
		result = result+"]}";
		
		System.out.println(result);   
		
		return result;
	}

}
