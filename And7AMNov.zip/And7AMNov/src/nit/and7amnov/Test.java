package nit.and7amnov;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/test")
public class Test {

	@Path("/hi")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHi( )
	{
return "Hi! I am working fine, u can proceed";
	}
	
}
